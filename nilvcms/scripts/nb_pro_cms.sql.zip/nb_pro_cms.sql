-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 05-08-2013 a las 16:06:34
-- Versión del servidor: 5.5.30
-- Versión de PHP: 5.3.22
-- 
-- Base de datos: `nb_pro_cms`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `Privilegios`
-- 

CREATE TABLE `Privilegios` (
  `id` int(99) NOT NULL AUTO_INCREMENT COMMENT 'Codigo',
  `nombre` varchar(70) NOT NULL COMMENT 'Nombre privilegio',
  `estado` varchar(1) NOT NULL COMMENT 'Estado: A = Activo, I=Inactivo',
  `fecha` date NOT NULL COMMENT 'Fecha de creacion o modificacion',
  `id_usuario` varchar(999) NOT NULL COMMENT 'Codigo del usuario',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `Privilegios`
-- 

INSERT INTO `Privilegios` (`id`, `nombre`, `estado`, `fecha`, `id_usuario`) VALUES 
(2, 'Crear%20usuarios', 'A', '2012-09-21', 'jperez'),
(3, 'Modificar%20usuarios', 'A', '2012-09-21', 'jperez');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `categorias`
-- 

CREATE TABLE `categorias` (
  `id` int(99) NOT NULL AUTO_INCREMENT COMMENT 'Codigo',
  `nombre` varchar(70) NOT NULL COMMENT 'Nombre Categoria',
  `estado` varchar(1) NOT NULL COMMENT 'Estado: A = Activo, I=Inactivo',
  `fecha` date NOT NULL COMMENT 'Fecha de creacion o modificacion',
  `id_usuario` varchar(999) NOT NULL COMMENT 'Codigo del usuario',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `categorias`
-- 

INSERT INTO `categorias` (`id`, `nombre`, `estado`, `fecha`, `id_usuario`) VALUES 
(2, 'Videos', 'A', '2012-09-21', 'jperez');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `grupos`
-- 

CREATE TABLE `grupos` (
  `id` int(99) NOT NULL AUTO_INCREMENT COMMENT 'Codigo',
  `nombre` varchar(70) NOT NULL COMMENT 'Nombre grupo',
  `estado` varchar(2) NOT NULL COMMENT 'Estado: A = Activo, I=Inactivo',
  `fecha` date NOT NULL COMMENT 'Fecha de creacion o modificacion',
  `id_usuario` varchar(999) NOT NULL COMMENT 'Nombre del usuario que crea o modifica',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `grupos`
-- 

INSERT INTO `grupos` (`id`, `nombre`, `estado`, `fecha`, `id_usuario`) VALUES 
(1, 'Administrador', 'A', '2012-09-21', 'jperez'),
(2, 'Visitantes', 'A', '2012-09-21', 'jperez');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `log`
-- 

CREATE TABLE `log` (
  `ip` varchar(999) NOT NULL COMMENT 'IP del usuario',
  `macadd` varchar(999) NOT NULL DEFAULT '' COMMENT 'MacAdress del usuario',
  `accion` varchar(999) DEFAULT NULL COMMENT 'Accion del usuario',
  `fecha` date NOT NULL COMMENT 'Fecha de la accion',
  `hostname` varchar(999) DEFAULT NULL COMMENT 'Hostname del usuario',
  PRIMARY KEY (`macadd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Logs de la aplicacion';

-- 
-- Volcar la base de datos para la tabla `log`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `rel_priv_grup`
-- 

CREATE TABLE `rel_priv_grup` (
  `id_priv` varchar(999) NOT NULL COMMENT 'Codigo privilegio',
  `id_grupo` int(99) NOT NULL COMMENT 'Codigo grupo'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Privilegios para cada grupo';

-- 
-- Volcar la base de datos para la tabla `rel_priv_grup`
-- 

INSERT INTO `rel_priv_grup` (`id_priv`, `id_grupo`) VALUES 
('7', 1),
('6', 1),
('5', 1),
('4', 1),
('2', 1),
('1', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `rel_usu_grup`
-- 

CREATE TABLE `rel_usu_grup` (
  `id_usuario` varchar(999) NOT NULL COMMENT 'Codigo usuario',
  `id_grupo` int(99) NOT NULL COMMENT 'Codigo grupo'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Grupos para cada usuario';

-- 
-- Volcar la base de datos para la tabla `rel_usu_grup`
-- 

INSERT INTO `rel_usu_grup` (`id_usuario`, `id_grupo`) VALUES 
('1', 4),
('1', 2),
('1', 1),
('1', 5),
('1', 6),
('1', 7),
('theeclipce', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` varchar(999) NOT NULL COMMENT 'Codigo del usuario',
  `nombre` varchar(25) NOT NULL COMMENT 'Nombre del usuario',
  `apellido` varchar(50) NOT NULL COMMENT 'Apellidos del usuario',
  `email` varchar(70) NOT NULL COMMENT 'Correo del usuario',
  `passwd` varchar(70) NOT NULL COMMENT 'Passwd usuario',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `email`, `passwd`) VALUES 
('theeclipce', 'Erick', 'Guzman', 'theeclipcehtomail.com', 'bb37d6c3d2330b7c5fb52c0debe43546'),
('jperez', 'Juan', 'Perez', 'jperez@nilbug.com', '25ba69291750e4ac2f759b1547b8fcb4'),
('theeclipces', 'Erick', 'Guzman', 'theeclipcehtomail.com', '25ba69291750e4ac2f759b1547b8fcb4'),
('jsoriano', 'Julio', 'Cesar', 'csoarianoaaa.com', '25ba69291750e4ac2f759b1547b8fcb4'),
('jsorianos', 'Julio', 'Cesar', 'csoarianoaaa.com', '25ba69291750e4ac2f759b1547b8fcb4'),
('jsorianox', 'Julio', 'Soriano', 'jsorianoaaa.com.do', '25ba69291750e4ac2f759b1547b8fcb4');
